module.exports = {
    //? YYMMDD .
    version: '240925'
};
